import SwiftUI
import Foundation

struct LocationSearchResponse: Decodable {
    let results: [City]?
}

struct City: Decodable, Identifiable, Hashable {
    let id: Int
    let name: String
    let latitude: Double
    let longitude: Double
    let country: String
    let admin1: String?
    let timezone: String?
}

struct ForecastResponse: Decodable {
    let latitude: Double
    let longitude: Double
    let timezone: String
    let current: CurrentWeather
    let hourly: HourlyWeather
}

struct CurrentWeather: Decodable {
    let time: String
    let temperature_2m: Double
    let apparent_temperature: Double
    let wind_speed_10m: Double
    let weather_code: Int
}

struct HourlyWeather: Decodable {
    let time: [String]
    let temperature_2m: [Double]
    let precipitation_probability: [Int]
}

struct HourlyForecastItem: Identifiable {
    let id = UUID()
    let time: String
    let temperature: Double
    let precipitationProbability: Int
}

// MARK: - Service

final class WeatherAPIService {
    static let shared = WeatherAPIService()
    private init() {}

    func searchCities(query: String) async throws -> [City] {
        guard let encoded = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else {
            return []
        }

        let urlString = "https://geocoding-api.open-meteo.com/v1/search?name=\(encoded)&count=10&language=en&format=json"
        guard let url = URL(string: urlString) else {
            throw URLError(.badURL)
        }

        let (data, response) = try await URLSession.shared.data(from: url)
        guard let httpResponse = response as? HTTPURLResponse,
              200..<300 ~= httpResponse.statusCode else {
            throw URLError(.badServerResponse)
        }

        let decoded = try JSONDecoder().decode(LocationSearchResponse.self, from: data)
        return decoded.results ?? []
    }

    func fetchForecast(latitude: Double, longitude: Double, timezone: String = "auto") async throws -> ForecastResponse {
        let urlString = "https://api.open-meteo.com/v1/forecast?latitude=\(latitude)&longitude=\(longitude)&current=temperature_2m,apparent_temperature,wind_speed_10m,weather_code&hourly=temperature_2m,precipitation_probability&forecast_days=1&timezone=\(timezone)"

        guard let url = URL(string: urlString) else {
            throw URLError(.badURL)
        }

        let (data, response) = try await URLSession.shared.data(from: url)
        guard let httpResponse = response as? HTTPURLResponse,
              200..<300 ~= httpResponse.statusCode else {
            throw URLError(.badServerResponse)
        }

        return try JSONDecoder().decode(ForecastResponse.self, from: data)
    }
}

@MainActor
final class CitySearchViewModel: ObservableObject {
    @Published var searchText: String = ""
    @Published var cities: [City] = []
    @Published var isLoading = false
    @Published var errorMessage: String?

    private let service: WeatherAPIService

    init(service: WeatherAPIService = .shared) {
        self.service = service
    }

    func search() async {
        let trimmed = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else {
            cities = []
            return
        }

        isLoading = true
        errorMessage = nil

        do {
            cities = try await service.searchCities(query: trimmed)
        } catch {
            errorMessage = "Error: \(error.localizedDescription)"
            cities = []
        }

        isLoading = false
    }
}

@MainActor
final class WeatherDetailViewModel: ObservableObject {
    @Published var forecast: ForecastResponse?
    @Published var hourlyItems: [HourlyForecastItem] = []
    @Published var isLoading = false
    @Published var errorMessage: String?

    let city: City
    private let service = WeatherAPIService.shared

    init(city: City) {
        self.city = city
    }

    func loadWeather() async {
        isLoading = true

        do {
            let result = try await service.fetchForecast(
                latitude: city.latitude,
                longitude: city.longitude
            )
            forecast = result
            hourlyItems = zip(result.hourly.time, zip(result.hourly.temperature_2m, result.hourly.precipitation_probability)).map {
                HourlyForecastItem(time: $0.0, temperature: $0.1.0, precipitationProbability: $0.1.1)
            }
        } catch {
            errorMessage = "Failed to load weather"
        }

        isLoading = false
    }
}

// MARK: - Views

struct ContentView: View {
    var body: some View {
        NavigationStack {
            CitySearchView()
        }
    }
}

struct CitySearchView: View {
    @StateObject private var viewModel = CitySearchViewModel()

    var body: some View {
        VStack {
            HStack {
                TextField("Enter city", text: $viewModel.searchText)
                    .textFieldStyle(.roundedBorder)

                Button("Search") {
                    Task { await viewModel.search() }
                }
            }
            .padding()

            if viewModel.isLoading {
                ProgressView()
            }

            List(viewModel.cities) { city in
                NavigationLink(value: city) {
                    VStack(alignment: .leading) {
                        Text(city.name).font(.headline)
                        Text("\(city.country)").font(.subheadline)
                    }
                }
            }
        }
        .navigationTitle("Weather App")
        .navigationDestination(for: City.self) { city in
            WeatherDetailView(viewModel: WeatherDetailViewModel(city: city))
        }
    }
}

struct WeatherDetailView: View {
    @StateObject var viewModel: WeatherDetailViewModel

    var body: some View {
        Group {
            if viewModel.isLoading {
                ProgressView()
            } else if let forecast = viewModel.forecast {
                List {
                    Text("Temp: \(forecast.current.temperature_2m, specifier: "%.1f")°C")
                    Text("Wind: \(forecast.current.wind_speed_10m, specifier: "%.1f") km/h")

                    Section("Hourly") {
                        ForEach(viewModel.hourlyItems.prefix(10)) { item in
                            VStack(alignment: .leading) {
                                Text(item.time)
                                Text("\(item.temperature, specifier: "%.1f")°C")
                            }
                        }
                    }
                }
            } else {
                Text("No Data")
            }
        }
        .navigationTitle(viewModel.city.name)
        .task {
            await viewModel.loadWeather()
        }
    }
}

#Preview {
    ContentView()
}
