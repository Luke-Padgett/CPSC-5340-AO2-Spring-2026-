//
//  Weather_MappApp.swift
//  Weather Mapp
//
//  Created by user285806 on 4/5/26.
//

import SwiftUI

@main
struct Weather_MappApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
