//
//  Weather_MappTests.swift
//  Weather MappTests
//
//  Created by user285806 on 4/5/26.
//

import Testing
@testable import Weather_Mapp

struct Weather_MappTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
