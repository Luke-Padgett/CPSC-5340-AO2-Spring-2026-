import SwiftUI
import FirebaseAuth

struct ContentView: View {
    @StateObject private var viewModel = AuthViewModel()

    var body: some View {
        Group {
            if viewModel.isAuthenticated {
                HomeView(viewModel: viewModel)
            } else {
                NavigationStack {
                    LoginView(viewModel: viewModel)
                }
            }
        }
        .onAppear {
            viewModel.listenToAuthState()
        }
    }
}

// MARK: - ViewModel

@MainActor
final class AuthViewModel: ObservableObject {
    @Published var email = ""
    @Published var password = ""
    @Published var isAuthenticated = false
    @Published var errorMessage = ""
    @Published var isLoading = false

    private var handle: AuthStateDidChangeListenerHandle?

    func listenToAuthState() {
        guard handle == nil else { return }

        handle = Auth.auth().addStateDidChangeListener { [weak self] _, user in
            print("👀 Auth state changed. User is nil? \(user == nil)")
            self?.isAuthenticated = (user != nil)
        }
    }

    func signUp() async {
        await authenticate(mode: .signUp)
    }

    func login() async {
        await authenticate(mode: .login)
    }

    private func authenticate(mode: AuthMode) async {
        print("authenticate() was called")
        errorMessage = ""

        let trimmedEmail = email.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedPassword = password.trimmingCharacters(in: .whitespacesAndNewlines)

        guard !trimmedEmail.isEmpty, !trimmedPassword.isEmpty else {
            errorMessage = "Email and password are required."
            print("Missing email or password")
            return
        }

        guard trimmedPassword.count >= 6 else {
            errorMessage = "Password must be at least 6 characters."
            print("Password too short")
            return
        }

        isLoading = true
        defer { isLoading = false }

        do {
            switch mode {
            case .signUp:
                print("Trying to create user with email: \(trimmedEmail)")
                let result = try await Auth.auth().createUser(withEmail: trimmedEmail, password: trimmedPassword)
                print("User created successfully: \(result.user.uid)")

            case .login:
                print("Trying to sign in with email: \(trimmedEmail)")
                let result = try await Auth.auth().signIn(withEmail: trimmedEmail, password: trimmedPassword)
                print("Login successful: \(result.user.uid)")
            }
        } catch {
            print("Firebase auth raw error:", error)
            print("Firebase auth NSError:", error as NSError)
            errorMessage = firebaseMessage(for: error)
        }
    }

    func logout() {
        do {
            try Auth.auth().signOut()
            email = ""
            password = ""
            errorMessage = ""
            print("User logged out")
        } catch {
            print("Logout error:", error)
            errorMessage = "Could not log out. Please try again."
        }
    }

    private func firebaseMessage(for error: Error) -> String {
        let nsError = error as NSError

        if let code = AuthErrorCode(rawValue: nsError.code) {
            switch code {
            case .invalidEmail:
                return "That email address is not valid."
            case .emailAlreadyInUse:
                return "That email is already in use."
            case .wrongPassword:
                return "Incorrect password."
            case .userNotFound:
                return "No account found for that email."
            case .networkError:
                return "Network error. Check your connection and try again."
            case .weakPassword:
                return "Password is too weak. Use at least 6 characters."
            default:
                return nsError.localizedDescription
            }
        }

        return nsError.localizedDescription
    }

    deinit {
        if let handle {
            Auth.auth().removeStateDidChangeListener(handle)
        }
    }
}

enum AuthMode {
    case signUp
    case login
}

// MARK: - Views

struct LoginView: View {
    @ObservedObject var viewModel: AuthViewModel

    var body: some View {
        VStack(spacing: 20) {
            Text("Firebase Auth Demo")
                .font(.largeTitle)
                .fontWeight(.bold)

            TextField("Email", text: $viewModel.email)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .keyboardType(.emailAddress)
                .textFieldStyle(.roundedBorder)

            SecureField("Password", text: $viewModel.password)
                .textFieldStyle(.roundedBorder)

            if !viewModel.errorMessage.isEmpty {
                Text(viewModel.errorMessage)
                    .foregroundColor(.red)
                    .multilineTextAlignment(.center)
            }

            if viewModel.isLoading {
                ProgressView()
            }

            Button {
                Task { await viewModel.login() }
            } label: {
                Text("Login")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .disabled(viewModel.isLoading)

            NavigationLink("Create an account") {
                SignUpView(viewModel: viewModel)
            }

            Spacer()
        }
        .padding()
        .navigationTitle("Login")
    }
}

struct SignUpView: View {
    @ObservedObject var viewModel: AuthViewModel

    var body: some View {
        VStack(spacing: 20) {
            Text("Create Account")
                .font(.largeTitle)
                .fontWeight(.bold)

            TextField("Email", text: $viewModel.email)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .keyboardType(.emailAddress)
                .textFieldStyle(.roundedBorder)

            SecureField("Password", text: $viewModel.password)
                .textFieldStyle(.roundedBorder)

            if !viewModel.errorMessage.isEmpty {
                Text(viewModel.errorMessage)
                    .foregroundColor(.red)
                    .multilineTextAlignment(.center)
            }

            if viewModel.isLoading {
                ProgressView()
            }

            Button {
                Task { await viewModel.signUp() }
            } label: {
                Text("Sign Up")
                    .frame(maxWidth: .infinity)
            }
            .buttonStyle(.borderedProminent)
            .disabled(viewModel.isLoading)

            Spacer()
        }
        .padding()
        .navigationTitle("Sign Up")
    }
}

struct HomeView: View {
    @ObservedObject var viewModel: AuthViewModel

    var body: some View {
        NavigationStack {
            VStack(spacing: 20) {
                Image(systemName: "person.crop.circle.badge.checkmark")
                    .font(.system(size: 70))
                    .foregroundColor(.green)

                Text("You are logged in")
                    .font(.title)
                    .fontWeight(.semibold)

                Text(Auth.auth().currentUser?.email ?? "No email found")
                    .foregroundColor(.secondary)

                NavigationLink("Go to Profile Details") {
                    ProfileDetailView()
                }
                .buttonStyle(.bordered)

                Button(role: .destructive) {
                    viewModel.logout()
                } label: {
                    Text("Logout")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .padding(.top)

                Spacer()
            }
            .padding()
            .navigationTitle("Home")
        }
    }
}

struct ProfileDetailView: View {
    var body: some View {
        VStack(spacing: 16) {
            Text("Profile Details")
                .font(.title)
                .fontWeight(.bold)

            Text("This screen exists to demonstrate basic navigation after login.")
                .multilineTextAlignment(.center)
                .foregroundColor(.secondary)
        }
        .padding()
        .navigationTitle("Details")
    }
}

#Preview {
    ContentView()
}
